"""OpenRouter client with a hard spending cap. Every call is logged with its real cost."""
import json, os, pathlib, urllib.request, urllib.error, fcntl

CAP_USD = 5.00
LEDGER = pathlib.Path.home() / '.config/apart/spend.json'
LOG = pathlib.Path.home() / '.config/apart/calls.jsonl'


def _key():
    for line in (pathlib.Path.home() / '.config/apart/openrouter.env').read_text().splitlines():
        if line.startswith('OPENROUTER_API_KEY='):
            return line.split('=', 1)[1].strip()
    raise RuntimeError('key file missing')


def spent():
    return json.loads(LEDGER.read_text())['usd'] if LEDGER.exists() else 0.0


def _add(cost, model, usage):
    LEDGER.parent.mkdir(parents=True, exist_ok=True)
    with open(LEDGER.parent / 'spend.lock', 'w') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        total = spent() + cost
        LEDGER.write_text(json.dumps({'usd': total}))
        with LOG.open('a') as f:
            f.write(json.dumps({'model': model, 'cost': cost, 'usage': usage, 'total': total}) + '\n')
    return total


def chat(model, system, user, schema=None, seed=0, temperature=0.3, max_tokens=250):
    if spent() >= CAP_USD:
        raise RuntimeError(f'Spend cap reached: ${spent():.4f} >= ${CAP_USD:.2f}')
    body = {'model': model, 'seed': seed, 'temperature': temperature, 'max_tokens': max_tokens,
            'messages': [{'role': 'system', 'content': system}, {'role': 'user', 'content': user}],
            'usage': {'include': True}}
    if schema:
        body['response_format'] = {'type': 'json_schema', 'json_schema': {'name': 'out', 'strict': True, 'schema': schema}}
    req = urllib.request.Request('https://openrouter.ai/api/v1/chat/completions', json.dumps(body).encode(),
                                 {'Content-Type': 'application/json', 'Authorization': 'Bearer ' + _key()})
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            out = json.load(r)
    except urllib.error.HTTPError as e:
        raise RuntimeError(f'HTTP {e.code}: {e.read()[:300]!r}')
    usage = out.get('usage', {})
    _add(float(usage.get('cost', 0.0)), model, {k: usage.get(k) for k in ('prompt_tokens', 'completion_tokens')})
    text = out['choices'][0]['message']['content']
    return json.loads(text) if schema else text
