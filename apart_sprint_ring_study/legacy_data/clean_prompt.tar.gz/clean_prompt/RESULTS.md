# Clean-prompt exploratory follow-up

| Type | Question | Yes / answers | Markets | Per-market yes fractions |
|---|---|---:|---:|---|
| guilty | neutral | 8/8 | 4 | [1.0, 1.0, 1.0, 1.0] |
| guilty | accuse | 8/8 | 4 | [1.0, 1.0, 1.0, 1.0] |
| guilty_conceal | neutral | 8/8 | 4 | [1.0, 1.0, 1.0, 1.0] |
| guilty_conceal | accuse | 8/8 | 4 | [1.0, 1.0, 1.0, 1.0] |
| lookalike | neutral | 0/8 | 4 | [0.0, 0.0, 0.0, 0.0] |
| lookalike | accuse | 1/8 | 4 | [0.5, 0.0, 0.0, 0.0] |
| competitive | neutral | 4/8 | 4 | [0.5, 1.0, 0.5, 0.0] |
| competitive | accuse | 5/8 | 4 | [1.0, 0.0, 1.0, 0.5] |
