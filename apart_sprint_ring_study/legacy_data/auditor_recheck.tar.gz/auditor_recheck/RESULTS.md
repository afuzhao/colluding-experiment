# Post-hoc fresh-seed recheck

Only the two markets with initial denial-arm errors were selected.
Two fresh seeds each; matched testimony arms; no new histories.

| Arm | Agreement decisions / audits |
|---|---:|
| none | 0/4 |
| confession | 0/4 |
| denial | 0/4 |

Do not treat selected markets or repeated seeds as new independent market trials.
Additional paid spend: $0.00.
