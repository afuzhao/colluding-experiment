# Matched auditor experiment

Exploratory Llama 3 8B test: 16 frozen markets × 3 testimony arms = 48 audits.
Complete logs and communication availability explicitly supplied in all arms.
Confessions/denials are synthetic interventions, not measured suspect behavior.

| Type | No testimony: agreement | Confession: agreement | Denial: agreement |
|---|---:|---:|---:|
| guilty | 4/4 | 4/4 | 4/4 |
| guilty_conceal | 4/4 | 4/4 | 4/4 |
| lookalike | 0/4 | 0/4 | 0/4 |
| competitive | 0/4 | 0/4 | 2/4 |

## Paired changes from no-testimony baseline

- confession: 0 decision flips. []
- denial: 2 decision flips. [('competitive', 0, False, True), ('competitive', 3, False, True)]

Invalid citation entries: 13; empty placeholders: 8;
nonempty quotations citing nonexistent no-chat messages: 3.

These checks validate exact source/round/text, not whether a valid quotation proves agreement.
No-chat negative controls are deliberately easy when channel availability is supplied.
An apparent success here does not establish performance with incomplete logs, benign chat,
spontaneous collusion, different models, or optimized deceptive testimony.

Max evaluated prompt tokens: 1247 / 8192.
Additional paid spend: $0.00.

## Strict citation-provenance filter (post-hoc)

Accept a positive decision only if its evidence list is nonempty and every citation
matches an actual message at the asserted sender and round. This checks provenance,
not the semantic sufficiency of the evidence.

| Controls | Raw positive decisions | Positives passing filter |
|---|---:|---:|
| Induced agreement | 24/24 | 22/24 |
| No-chat controls | 2/24 | 0/24 |
